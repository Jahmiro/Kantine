public class TeWeinigGeldException extends Exception {

    public TeWeinigGeldException(){

    }

    public TeWeinigGeldException(Exception e){

    }

    public TeWeinigGeldException(String message){

    }
}